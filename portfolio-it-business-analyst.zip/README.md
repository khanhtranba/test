# Portfolio IT Business Analyst

Website portfolio tĩnh bằng HTML, CSS và JavaScript thuần. Không cần backend, package manager hay bước build; có thể đưa trực tiếp lên GitHub Pages.

## Cấu trúc thư mục

```text
portfolio/
├── index.html          # Nội dung và các phần của trang
├── css/style.css       # Màu sắc, bố cục, responsive
├── js/main.js          # Menu di động, điều hướng, năm bản quyền
├── assets/favicon.svg  # Biểu tượng trình duyệt
└── README.md           # Hướng dẫn tùy chỉnh và deploy
```

## Tùy chỉnh nội dung

Mở `index.html` bằng trình soạn thảo và thay các thông tin mẫu:

- Tìm `Minh Anh` để đổi tên hiển thị, tiêu đề trang và phần chân trang.
- Cập nhật đoạn giới thiệu, địa điểm, số năm kinh nghiệm và số liệu ở mục Giới thiệu.
- Sửa chức danh, loại hình tổ chức, thời gian và gạch đầu dòng trong mục Kinh nghiệm.
- Điều chỉnh nhóm kỹ năng, công cụ và thẻ công nghệ theo năng lực thực tế.
- Viết lại thẻ Dự án bằng mô tả đã được phép công bố. Các tên tổ chức và số liệu hiện tại chỉ là mẫu minh họa; hãy xóa số liệu hoặc thay bằng số liệu đã được xác minh và được phép chia sẻ.
- Thay `hello@example.com`, `your-profile` và `your-username` bằng email và liên kết công khai của bạn. Xóa liên kết chưa dùng.
- Sửa mô tả SEO trong thẻ `<meta name="description">` và `theme-color` nếu muốn.

Các màu chính nằm ở đầu `css/style.css` trong khối `:root`. Có thể đổi `--bg`, `--panel`, `--text`, `--muted`, `--purple`, `--mint`, `--blue` để tạo bảng màu riêng. Font DM Sans và Manrope được tải từ Google Fonts; nếu muốn trang không phụ thuộc dịch vụ ngoài, bỏ dòng `@import` và để trình duyệt dùng font dự phòng.

## Xem thử trên máy

Mở `index.html` trực tiếp trên trình duyệt. Để mô phỏng máy chủ web, chạy một máy chủ tĩnh từ thư mục `portfolio` (ví dụ với Python đã cài):

```bash
python -m http.server 8000
```

Sau đó mở `http://localhost:8000`. Dừng máy chủ bằng `Ctrl+C`.

## Deploy miễn phí bằng GitHub Pages

1. Tạo repository GitHub mới. Để dùng URL dạng `https://TEN-TAI-KHOAN.github.io/`, đặt tên repository là `TEN-TAI-KHOAN.github.io`; nếu dùng tên khác, trang sẽ ở `https://TEN-TAI-KHOAN.github.io/TEN-REPOSITORY/`.
2. Đưa các file bên trong thư mục `portfolio` lên thư mục gốc của repository. Không cần đưa file ZIP lên để chạy trang.
3. Trên GitHub, mở **Settings → Pages**.
4. Ở phần build and deployment, chọn **Deploy from a branch**, chọn nhánh `main` và thư mục `/(root)`, sau đó lưu.
5. Chờ GitHub Pages hoàn tất lần xuất bản đầu; mở URL được hiển thị trong phần Pages. Các lần cập nhật sẽ được xuất bản khi bạn đẩy commit mới lên nhánh đã chọn.

## Bảo mật và quyền riêng tư

- Mọi nội dung trong repository public đều có thể được xem và tải xuống. Chỉ công bố thông tin bạn muốn chia sẻ rộng rãi.
- Không đưa mật khẩu, token, API key, dữ liệu cá nhân của khách hàng, ảnh chụp màn hình nội bộ, tài liệu hợp đồng, tên hệ thống hoặc URL nội bộ vào website hay lịch sử Git.
- Dự án trong mẫu được mô tả tổng quát, không có tên khách hàng hoặc URL nội bộ. Hãy giữ mức ẩn danh này và chỉ nêu kết quả đã được tổ chức cho phép công bố.
- Website không có backend và không thu thập form liên hệ. Email hiển thị sẽ được người xem nhìn thấy; cân nhắc dùng địa chỉ chuyên dùng cho portfolio.
- Liên kết ngoài dùng `rel="noopener noreferrer"` khi mở tab mới. Kiểm tra lại mọi URL trước khi xuất bản.
- GitHub Pages phục vụ website qua HTTPS. Tránh nhúng script, font hoặc thư viện từ nguồn không tin cậy; font ngoài có thể bị loại bỏ để giảm phụ thuộc.

## Khả năng tiếp cận

Trang có điều hướng bàn phím, nhãn menu di động, liên kết bỏ qua điều hướng, cấu trúc tiêu đề và breakpoint cho màn hình nhỏ. Khi chỉnh sửa, giữ tương phản chữ/nền tốt và thêm văn bản thay thế nếu bổ sung hình ảnh có ý nghĩa.
